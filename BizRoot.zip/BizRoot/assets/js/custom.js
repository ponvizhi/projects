$(window).scroll(function () {
  console.log($(window).scrollTop())
  if ($(window).scrollTop() > 63) {
    $('header').addClass('navbar-fixed');
  }
  if ($(window).scrollTop() < 64) {
    $('header').removeClass('navbar-fixed');
  }
});



// Init slick slider + animation
$('.bannerslider').slick({
  autoplay: false,
  speed: 800,
  lazyLoad: 'progressive',
  arrows: false,
  dots: false,
	prevArrow: '<div class="slick-nav prev-arrow"><i></i><svg><use xlink:href="#circle"></svg></div>',
	nextArrow: '<div class="slick-nav next-arrow"><i></i><svg><use xlink:href="#circle"></svg></div>',
}).slickAnimation();



$('.slick-nav').on('click touch', function(e) {

    e.preventDefault();

    var arrow = $(this);

    if(!arrow.hasClass('animate')) {
        arrow.addClass('animate');
        setTimeout(() => {
            arrow.removeClass('animate');
        }, 1600);
    }

});

//about slick slider
$('.about-slider-nav').slick({
  autoplay: false,
  slidesToShow: 2,
   slidesToScroll: 1,
  speed: 800,
  lazyLoad: 'progressive',
  arrows: true,
  dots: false,
	prevArrow: '<div class="slick-nav prev-arrow"><i class="fas fa-angle-left"></i></div>',
	nextArrow: '<div class="slick-nav next-arrow"><i class="fas fa-angle-right"></i></div>',
	 responsive: [
    {
      breakpoint: 1024,
      settings: {
        slidesToShow: 2,
        slidesToScroll: 3,
        infinite: true,
        dots: true
      }
    },
    {
      breakpoint: 992,
      settings: {
        slidesToShow: 2,
        slidesToScroll: 2
      }
    },
    {
      breakpoint: 768,
      settings: {
        slidesToShow: 1,
        slidesToScroll: 1
      }
    }
    // You can unslick at a given breakpoint now by adding:
    // settings: "unslick"
    // instead of a settings object
  ]
}).slickAnimation();


$('.ourcase-slider-nav').slick({
  autoplay: true,
  slidesToShow: 3,
   slidesToScroll: 1,
  speed: 800,
  lazyLoad: 'progressive',
  arrows: false,
  dots: true,
  responsive: [
    {
      breakpoint: 1024,
      settings: {
        slidesToShow: 3,
        slidesToScroll: 3,
        infinite: true,
        dots: true
      }
    },
    {
      breakpoint: 992,
      settings: {
        slidesToShow: 2,
        slidesToScroll: 2
      }
    },
    {
      breakpoint: 768,
      settings: {
        slidesToShow: 1,
        slidesToScroll: 1
      }
    }
    // You can unslick at a given breakpoint now by adding:
    // settings: "unslick"
    // instead of a settings object
  ]
}).slickAnimation();


$('.testimonial-slider-nav').slick({
  autoplay: true,
  slidesToShow: 1,
   slidesToScroll: 1,
  speed: 800,
  lazyLoad: 'progressive',
  arrows: false,
  dots: true,
}).slickAnimation();


//count up

$(window).scroll(function() {
  var a = 0;
  var oTop = $('#counter').offset().top - window.innerHeight;
  console.log($('#counter').offset().top);
  if (a == 0 && $(window).scrollTop() > oTop) {
    $('.counter-value').each(function() {
      var $this = $(this),
        countTo = $this.attr('data-count');
      $({
        countNum: $this.text()
      }).animate({
          countNum: countTo
        },

        {

          duration: 2000,
          easing: 'swing',
          step: function() {
            $this.text(Math.floor(this.countNum));
          },
          complete: function() {
            $this.text(this.countNum);
            //alert('finished');
          }

        });
    });
    a = 1;
  }

});

//form validation
 $(document).ready(function($) {
        
				$("#request-form").validate({
                rules: {
                    fname: "required",                    
                   lname: "required",
                  email: "required",
                  pnumber: "required",
                  servicetype: "required",
                  message: "required"
                 
                },
                messages: {
                  fname: "Please enter your First Name",                   
                  lname: "Please enter your Last Name",
                  email: "Please enter your Email",
                  pnumber: "Please enter your Phone Number",
                  servicetype: "Please select Service",
                  message: "Please enter your Message",
                },
                 errorPlacement: function(error, element) 
        {
            if ( element.is(":radio") ) 
            {
                error.appendTo( element.parents('.form-group') );
            }
            else 
            { // This is the default behavior 
                error.insertAfter( element );
            }
         },
                submitHandler: function(form) {
                    form.submit();
                }
                
            });
    });

